import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/container.dart';
import 'package:flutter/src/widgets/framework.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  bool isLogin = false;
  String selectedDropdown = "";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        padding: const EdgeInsets.all(10),
        child: Column(
          children:  [
            Checkbox(
              value: isLogin,
              onChanged: (value)=>{
                isLogin = value!
              }
            ),
            CheckboxListTile(
              title: Text(isLogin==true ? "owo" : "uwu"),
              secondary: const Icon(Icons.add),
              value: isLogin,
              onChanged: (value)=>{
                setState(()=>{
                  isLogin = value!
                })
              },
            ),
            DropdownButton(
              items: [
                "owo",
                "uwu"
              ].map((e) => 
                DropdownMenuItem<String>(child: Text(e), value: e,)
              ).toList(), 
              onChanged: (value)=>{
                setState(()=>{
                  selectedDropdown = value! 
                })
              }
            ),
            Text(selectedDropdown)
          ],
        ),
      )
    );
  }
}